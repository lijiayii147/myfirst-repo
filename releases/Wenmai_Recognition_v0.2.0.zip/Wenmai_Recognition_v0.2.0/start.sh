#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-lock.txt
exec .venv/bin/python -m uvicorn wenmai.app:app --host 127.0.0.1 --port 8000
